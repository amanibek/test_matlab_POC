
function description = GetAliconaDataDescription(data)

description = data.XMLData.Object3D.generalData.description;